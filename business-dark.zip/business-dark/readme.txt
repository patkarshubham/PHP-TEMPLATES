=== Business Dark ===
Contributors: wptexture      
Requires at least:  4.9.7
Tested up to:       5.7.2
Requires PHP:       5.2.4
Stable tag:         1.5
License:            GPLv3 or later
License URI:        http://www.gnu.org/licenses/gpl-3.0.html
Tags: left-sidebar, right-sidebar, one-column, two-columns, three-columns, four-columns, grid-layout, custom-colors, custom-background, custom-logo, custom-menu, custom-header, editor-style, featured-images, footer-widgets, sticky-post, full-width-template, theme-options, translation-ready, threaded-comments, post-formats, rtl-language-support, blog, portfolio, e-commerce

== Description ==
Business Dark Theme

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Copyright ==

Business Dark WordPress Theme, Copyright 2021, wptexture  
Business Dark is distributed under the terms of the GNU GPL

Agency Business bundles the following third-party resources:

	Font Awesome by Dave Gandy
    Licenses: SIL OFL 1.1, MIT, CC BY 3.0
    Source: https://github.com/FontAwesome/Font-Awesome

    Bootstrap by Twitter
    License: MIT
    Source: https://github.com/twbs/bootstrap

    Owl Carousel by David Deutsch
    License: MIT
    Source: https://github.com/OwlCarousel2/OwlCarousel2

    Magnific Popup by Dmitry Semenov
    License: MIT
    Source: http://dimsemenov.com/plugins/magnific-popup/

 

== Screenshots ==
    Licenses: Screenshots Image 
	License: CC0 1.0 Universal (CC0 1.0)
	License URL: https://pxhere.com/en/license
	Source: https://pxhere.com/en/photo/1631306
       