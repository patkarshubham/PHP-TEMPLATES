<footer class="entry-footer">
	<?php bingle_entry_footer(); ?>
</footer><!-- .entry-footer -->