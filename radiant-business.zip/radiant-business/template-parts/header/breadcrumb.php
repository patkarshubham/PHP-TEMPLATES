<?php
/**
 * Displays breadcrumb
 *
 * @package Radiant Business
 */

radiant_business_breadcrumb();
