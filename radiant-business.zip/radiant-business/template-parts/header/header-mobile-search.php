<?php
/**
 * Header Mobile Search
 *
 * @package Radiant Business
 */
?>
<div class="mobile-search">
	<?php get_search_form(); ?>
</div><!-- .mobile-search -->
