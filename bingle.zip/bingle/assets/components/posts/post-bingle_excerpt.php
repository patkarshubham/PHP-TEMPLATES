<div class="entry-content">
	<?php the_excerpt();	?>
	<a href="<?php the_permalink();?>" class="btn read-more"><?php esc_html_e('Read More','bingle');?></a>
</div><!-- .entry-content -->