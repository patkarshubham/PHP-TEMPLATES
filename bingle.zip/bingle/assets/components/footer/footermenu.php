<div class="footermenu clear">
	<?php
	wp_nav_menu( array(
		'theme_location' => 'menu-2',
		'menu_id'        => 'footer-menu',
	) );
	?>
</div>